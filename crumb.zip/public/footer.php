<footer class="footer">
<h3 class="text-ellipsis">&copy;2021 Copyright&nbsp;&nbsp;<a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a></h3>
</footer>
