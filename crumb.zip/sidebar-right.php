<div class="sidebar-right">
<div class="sidebar-r">
<div class="sidebar-r-top">
<span id="sidebar-tags">#标签云</span>
<?php $this->widget('Widget_Metas_Tag_Cloud','ignoreZeroCount=1&limit=25')->to($tags); ?>
     <?php while($tags->next()):?>
     <span style="background-color:rgb(<?php echo(rand(150,235)); ?>,<?php echo(rand(120,225)); ?>, <?php echo(rand(124,255)); ?>);" id="tags"> <a  href="<?php $tags->permalink();?>"><?php $tags->name();?></a></span>
      <?php endwhile;?>
</div>
<ul>
    <?php $this->widget('Widget_Comments_Recent','ignoreAuthor=true&pageSize=5')->to($comments); ?>
    <?php while($comments->next()): ?>
        <li><?php $email=$comments->mail; $imgUrl = getGravatar($email);echo '<img src="'.$imgUrl.'" width="45px" height="45px" style="border-radius: 50%;" >'; ?><?php $comments->author(false); ?>: <a href="<?php $comments->permalink(); ?>"><?php $comments->excerpt(50, '...'); ?></a></li>
    <?php endwhile; ?>
</ul>

</div></div></div>